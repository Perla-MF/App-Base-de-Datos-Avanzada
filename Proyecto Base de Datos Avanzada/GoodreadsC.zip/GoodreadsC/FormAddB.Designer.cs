﻿namespace GoodreadsC
{
    partial class FormAddB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAddB));
            panelFondo = new Panel();
            txtBoxDate = new TextBox();
            PBLimpiar = new PictureBox();
            PBAgregar = new PictureBox();
            txtBoxRT = new TextBox();
            txtBoxR5 = new TextBox();
            txtBoxR4 = new TextBox();
            txtBoxR3 = new TextBox();
            txtBoxR2 = new TextBox();
            txtBoxR1 = new TextBox();
            txtBoxAutor = new TextBox();
            txtBoxReseñas = new TextBox();
            txtBoxRating = new TextBox();
            txtBoxIdioma = new TextBox();
            txtBoxISBN = new TextBox();
            txtBoxEditorial = new TextBox();
            txtBoxAño = new TextBox();
            txtBoxDia = new TextBox();
            txtBoxMes = new TextBox();
            txtBoxPaginas = new TextBox();
            txtBoxTitulo = new TextBox();
            Label13 = new Label();
            Label14 = new Label();
            Label15 = new Label();
            Label16 = new Label();
            Label17 = new Label();
            Label18 = new Label();
            Label19 = new Label();
            Label20 = new Label();
            Label21 = new Label();
            Label10 = new Label();
            Label11 = new Label();
            Label6 = new Label();
            Label7 = new Label();
            Label8 = new Label();
            Label9 = new Label();
            Label4 = new Label();
            Label5 = new Label();
            Label3 = new Label();
            Label2 = new Label();
            PanelTitle = new Panel();
            label1 = new Label();
            pictureBox5 = new PictureBox();
            BtnClose = new PictureBox();
            PBMin = new PictureBox();
            PBRest = new PictureBox();
            PBMax = new PictureBox();
            PBClose = new PictureBox();
            PicBR = new PictureBox();
            picBMinimize = new PictureBox();
            PicBClose = new PictureBox();
            PicBMaximize = new PictureBox();
            panelFondo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PBLimpiar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBAgregar).BeginInit();
            PanelTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBMin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBRest).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBMax).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBR).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picBMinimize).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBMaximize).BeginInit();
            SuspendLayout();
            // 
            // panelFondo
            // 
            panelFondo.BackColor = Color.Cornsilk;
            panelFondo.Controls.Add(txtBoxDate);
            panelFondo.Controls.Add(PBLimpiar);
            panelFondo.Controls.Add(PBAgregar);
            panelFondo.Controls.Add(txtBoxRT);
            panelFondo.Controls.Add(txtBoxR5);
            panelFondo.Controls.Add(txtBoxR4);
            panelFondo.Controls.Add(txtBoxR3);
            panelFondo.Controls.Add(txtBoxR2);
            panelFondo.Controls.Add(txtBoxR1);
            panelFondo.Controls.Add(txtBoxAutor);
            panelFondo.Controls.Add(txtBoxReseñas);
            panelFondo.Controls.Add(txtBoxRating);
            panelFondo.Controls.Add(txtBoxIdioma);
            panelFondo.Controls.Add(txtBoxISBN);
            panelFondo.Controls.Add(txtBoxEditorial);
            panelFondo.Controls.Add(txtBoxAño);
            panelFondo.Controls.Add(txtBoxDia);
            panelFondo.Controls.Add(txtBoxMes);
            panelFondo.Controls.Add(txtBoxPaginas);
            panelFondo.Controls.Add(txtBoxTitulo);
            panelFondo.Controls.Add(Label13);
            panelFondo.Controls.Add(Label14);
            panelFondo.Controls.Add(Label15);
            panelFondo.Controls.Add(Label16);
            panelFondo.Controls.Add(Label17);
            panelFondo.Controls.Add(Label18);
            panelFondo.Controls.Add(Label19);
            panelFondo.Controls.Add(Label20);
            panelFondo.Controls.Add(Label21);
            panelFondo.Controls.Add(Label10);
            panelFondo.Controls.Add(Label11);
            panelFondo.Controls.Add(Label6);
            panelFondo.Controls.Add(Label7);
            panelFondo.Controls.Add(Label8);
            panelFondo.Controls.Add(Label9);
            panelFondo.Controls.Add(Label4);
            panelFondo.Controls.Add(Label5);
            panelFondo.Controls.Add(Label3);
            panelFondo.Controls.Add(Label2);
            panelFondo.Controls.Add(PanelTitle);
            panelFondo.Dock = DockStyle.Fill;
            panelFondo.Location = new Point(0, 0);
            panelFondo.Name = "panelFondo";
            panelFondo.Size = new Size(1115, 640);
            panelFondo.TabIndex = 0;
            // 
            // txtBoxDate
            // 
            txtBoxDate.Location = new Point(835, 168);
            txtBoxDate.Name = "txtBoxDate";
            txtBoxDate.Size = new Size(237, 27);
            txtBoxDate.TabIndex = 80;
            // 
            // PBLimpiar
            // 
            PBLimpiar.BackColor = Color.Cornsilk;
            PBLimpiar.Image = (Image)resources.GetObject("PBLimpiar.Image");
            PBLimpiar.Location = new Point(624, 560);
            PBLimpiar.Name = "PBLimpiar";
            PBLimpiar.Size = new Size(51, 54);
            PBLimpiar.SizeMode = PictureBoxSizeMode.StretchImage;
            PBLimpiar.TabIndex = 79;
            PBLimpiar.TabStop = false;
            PBLimpiar.Click += PBLimpiar_Click;
            // 
            // PBAgregar
            // 
            PBAgregar.BackColor = Color.Cornsilk;
            PBAgregar.Image = (Image)resources.GetObject("PBAgregar.Image");
            PBAgregar.Location = new Point(382, 560);
            PBAgregar.Name = "PBAgregar";
            PBAgregar.Size = new Size(57, 54);
            PBAgregar.SizeMode = PictureBoxSizeMode.StretchImage;
            PBAgregar.TabIndex = 78;
            PBAgregar.TabStop = false;
            PBAgregar.Click += PBAgregar_Click;
            // 
            // txtBoxRT
            // 
            txtBoxRT.Location = new Point(835, 490);
            txtBoxRT.Name = "txtBoxRT";
            txtBoxRT.Size = new Size(237, 27);
            txtBoxRT.TabIndex = 77;
            // 
            // txtBoxR5
            // 
            txtBoxR5.Location = new Point(835, 439);
            txtBoxR5.Name = "txtBoxR5";
            txtBoxR5.Size = new Size(237, 27);
            txtBoxR5.TabIndex = 76;
            // 
            // txtBoxR4
            // 
            txtBoxR4.Location = new Point(835, 384);
            txtBoxR4.Name = "txtBoxR4";
            txtBoxR4.Size = new Size(237, 27);
            txtBoxR4.TabIndex = 75;
            // 
            // txtBoxR3
            // 
            txtBoxR3.Location = new Point(835, 328);
            txtBoxR3.Name = "txtBoxR3";
            txtBoxR3.Size = new Size(237, 27);
            txtBoxR3.TabIndex = 74;
            // 
            // txtBoxR2
            // 
            txtBoxR2.Location = new Point(835, 271);
            txtBoxR2.Name = "txtBoxR2";
            txtBoxR2.Size = new Size(237, 27);
            txtBoxR2.TabIndex = 73;
            // 
            // txtBoxR1
            // 
            txtBoxR1.Location = new Point(835, 223);
            txtBoxR1.Name = "txtBoxR1";
            txtBoxR1.Size = new Size(237, 27);
            txtBoxR1.TabIndex = 72;
            // 
            // txtBoxAutor
            // 
            txtBoxAutor.Location = new Point(835, 115);
            txtBoxAutor.Name = "txtBoxAutor";
            txtBoxAutor.Size = new Size(237, 27);
            txtBoxAutor.TabIndex = 71;
            // 
            // txtBoxReseñas
            // 
            txtBoxReseñas.Location = new Point(835, 55);
            txtBoxReseñas.Name = "txtBoxReseñas";
            txtBoxReseñas.Size = new Size(237, 27);
            txtBoxReseñas.TabIndex = 70;
            // 
            // txtBoxRating
            // 
            txtBoxRating.Location = new Point(287, 490);
            txtBoxRating.Name = "txtBoxRating";
            txtBoxRating.Size = new Size(237, 27);
            txtBoxRating.TabIndex = 69;
            // 
            // txtBoxIdioma
            // 
            txtBoxIdioma.Location = new Point(287, 439);
            txtBoxIdioma.Name = "txtBoxIdioma";
            txtBoxIdioma.Size = new Size(237, 27);
            txtBoxIdioma.TabIndex = 68;
            // 
            // txtBoxISBN
            // 
            txtBoxISBN.Location = new Point(287, 384);
            txtBoxISBN.Name = "txtBoxISBN";
            txtBoxISBN.Size = new Size(237, 27);
            txtBoxISBN.TabIndex = 67;
            // 
            // txtBoxEditorial
            // 
            txtBoxEditorial.Location = new Point(287, 328);
            txtBoxEditorial.Name = "txtBoxEditorial";
            txtBoxEditorial.Size = new Size(237, 27);
            txtBoxEditorial.TabIndex = 66;
            // 
            // txtBoxAño
            // 
            txtBoxAño.Location = new Point(287, 271);
            txtBoxAño.Name = "txtBoxAño";
            txtBoxAño.Size = new Size(237, 27);
            txtBoxAño.TabIndex = 65;
            // 
            // txtBoxDia
            // 
            txtBoxDia.Location = new Point(287, 223);
            txtBoxDia.Name = "txtBoxDia";
            txtBoxDia.Size = new Size(237, 27);
            txtBoxDia.TabIndex = 64;
            // 
            // txtBoxMes
            // 
            txtBoxMes.Location = new Point(287, 168);
            txtBoxMes.Name = "txtBoxMes";
            txtBoxMes.Size = new Size(237, 27);
            txtBoxMes.TabIndex = 63;
            // 
            // txtBoxPaginas
            // 
            txtBoxPaginas.Location = new Point(287, 115);
            txtBoxPaginas.Name = "txtBoxPaginas";
            txtBoxPaginas.Size = new Size(237, 27);
            txtBoxPaginas.TabIndex = 62;
            // 
            // txtBoxTitulo
            // 
            txtBoxTitulo.Location = new Point(287, 55);
            txtBoxTitulo.Name = "txtBoxTitulo";
            txtBoxTitulo.Size = new Size(237, 27);
            txtBoxTitulo.TabIndex = 61;
            // 
            // Label13
            // 
            Label13.AutoSize = true;
            Label13.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label13.Location = new Point(581, 487);
            Label13.Name = "Label13";
            Label13.Size = new Size(0, 24);
            Label13.TabIndex = 60;
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label14.Location = new Point(581, 487);
            Label14.Name = "Label14";
            Label14.Size = new Size(150, 24);
            Label14.TabIndex = 59;
            Label14.Text = "Rating D. Total";
            // 
            // Label15
            // 
            Label15.AutoSize = true;
            Label15.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label15.Location = new Point(581, 439);
            Label15.Name = "Label15";
            Label15.Size = new Size(88, 24);
            Label15.TabIndex = 58;
            Label15.Text = "Rating 5";
            // 
            // Label16
            // 
            Label16.AutoSize = true;
            Label16.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label16.Location = new Point(581, 382);
            Label16.Name = "Label16";
            Label16.Size = new Size(88, 24);
            Label16.TabIndex = 57;
            Label16.Text = "Rating 4";
            // 
            // Label17
            // 
            Label17.AutoSize = true;
            Label17.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label17.Location = new Point(581, 328);
            Label17.Name = "Label17";
            Label17.Size = new Size(88, 24);
            Label17.TabIndex = 56;
            Label17.Text = "Rating 3";
            // 
            // Label18
            // 
            Label18.AutoSize = true;
            Label18.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label18.Location = new Point(581, 271);
            Label18.Name = "Label18";
            Label18.Size = new Size(88, 24);
            Label18.TabIndex = 55;
            Label18.Text = "Rating 2";
            // 
            // Label19
            // 
            Label19.AutoSize = true;
            Label19.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label19.Location = new Point(581, 223);
            Label19.Name = "Label19";
            Label19.Size = new Size(88, 24);
            Label19.TabIndex = 54;
            Label19.Text = "Rating 1";
            // 
            // Label20
            // 
            Label20.AutoSize = true;
            Label20.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label20.Location = new Point(581, 166);
            Label20.Name = "Label20";
            Label20.Size = new Size(67, 24);
            Label20.TabIndex = 53;
            Label20.Text = "Fecha";
            // 
            // Label21
            // 
            Label21.AutoSize = true;
            Label21.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label21.Location = new Point(581, 112);
            Label21.Name = "Label21";
            Label21.Size = new Size(62, 24);
            Label21.TabIndex = 52;
            Label21.Text = "Autor";
            // 
            // Label10
            // 
            Label10.AutoSize = true;
            Label10.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label10.Location = new Point(581, 55);
            Label10.Name = "Label10";
            Label10.Size = new Size(205, 24);
            Label10.TabIndex = 51;
            Label10.Text = "No. Total de reseñas";
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label11.Location = new Point(44, 487);
            Label11.Name = "Label11";
            Label11.Size = new Size(71, 24);
            Label11.TabIndex = 50;
            Label11.Text = "Rating";
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label6.Location = new Point(44, 439);
            Label6.Name = "Label6";
            Label6.Size = new Size(72, 24);
            Label6.TabIndex = 49;
            Label6.Text = "Idioma";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label7.Location = new Point(44, 382);
            Label7.Name = "Label7";
            Label7.Size = new Size(56, 24);
            Label7.TabIndex = 48;
            Label7.Text = "ISBN";
            // 
            // Label8
            // 
            Label8.AutoSize = true;
            Label8.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label8.Location = new Point(44, 328);
            Label8.Name = "Label8";
            Label8.Size = new Size(88, 24);
            Label8.TabIndex = 47;
            Label8.Text = "Editorial";
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label9.Location = new Point(44, 271);
            Label9.Name = "Label9";
            Label9.Size = new Size(190, 24);
            Label9.TabIndex = 46;
            Label9.Text = "Año de publicación";
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label4.Location = new Point(44, 223);
            Label4.Name = "Label4";
            Label4.Size = new Size(184, 24);
            Label4.TabIndex = 45;
            Label4.Text = "Día de publicación";
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label5.Location = new Point(44, 166);
            Label5.Name = "Label5";
            Label5.Size = new Size(192, 24);
            Label5.TabIndex = 44;
            Label5.Text = "Mes de publicación";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label3.Location = new Point(44, 112);
            Label3.Name = "Label3";
            Label3.Size = new Size(123, 24);
            Label3.TabIndex = 43;
            Label3.Text = "No. Páginas";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label2.Location = new Point(44, 55);
            Label2.Name = "Label2";
            Label2.Size = new Size(65, 24);
            Label2.TabIndex = 42;
            Label2.Text = "Título";
            // 
            // PanelTitle
            // 
            PanelTitle.BackColor = Color.FromArgb(108, 59, 42);
            PanelTitle.Controls.Add(label1);
            PanelTitle.Controls.Add(pictureBox5);
            PanelTitle.Controls.Add(BtnClose);
            PanelTitle.Controls.Add(PBMin);
            PanelTitle.Controls.Add(PBRest);
            PanelTitle.Controls.Add(PBMax);
            PanelTitle.Controls.Add(PBClose);
            PanelTitle.Controls.Add(PicBR);
            PanelTitle.Controls.Add(picBMinimize);
            PanelTitle.Controls.Add(PicBClose);
            PanelTitle.Controls.Add(PicBMaximize);
            PanelTitle.Dock = DockStyle.Top;
            PanelTitle.Location = new Point(0, 0);
            PanelTitle.Name = "PanelTitle";
            PanelTitle.Size = new Size(1115, 40);
            PanelTitle.TabIndex = 2;
            PanelTitle.MouseMove += PanelTitle_MouseMove;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(45, 3);
            label1.Name = "label1";
            label1.Size = new Size(200, 32);
            label1.TabIndex = 43;
            label1.Text = "Agregar Libro";
            // 
            // pictureBox5
            // 
            pictureBox5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(12, 6);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(27, 27);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 13;
            pictureBox5.TabStop = false;
            // 
            // BtnClose
            // 
            BtnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnClose.Image = (Image)resources.GetObject("BtnClose.Image");
            BtnClose.Location = new Point(1067, 6);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(27, 27);
            BtnClose.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnClose.TabIndex = 9;
            BtnClose.TabStop = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // PBMin
            // 
            PBMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBMin.Image = (Image)resources.GetObject("PBMin.Image");
            PBMin.Location = new Point(1753, 3);
            PBMin.Name = "PBMin";
            PBMin.Size = new Size(27, 27);
            PBMin.SizeMode = PictureBoxSizeMode.StretchImage;
            PBMin.TabIndex = 8;
            PBMin.TabStop = false;
            // 
            // PBRest
            // 
            PBRest.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBRest.Image = (Image)resources.GetObject("PBRest.Image");
            PBRest.Location = new Point(1795, 3);
            PBRest.Name = "PBRest";
            PBRest.Size = new Size(27, 27);
            PBRest.SizeMode = PictureBoxSizeMode.StretchImage;
            PBRest.TabIndex = 7;
            PBRest.TabStop = false;
            PBRest.Visible = false;
            // 
            // PBMax
            // 
            PBMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBMax.Image = (Image)resources.GetObject("PBMax.Image");
            PBMax.Location = new Point(1839, 3);
            PBMax.Name = "PBMax";
            PBMax.Size = new Size(27, 27);
            PBMax.SizeMode = PictureBoxSizeMode.StretchImage;
            PBMax.TabIndex = 6;
            PBMax.TabStop = false;
            // 
            // PBClose
            // 
            PBClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBClose.Image = (Image)resources.GetObject("PBClose.Image");
            PBClose.Location = new Point(1885, 3);
            PBClose.Name = "PBClose";
            PBClose.Size = new Size(27, 27);
            PBClose.SizeMode = PictureBoxSizeMode.StretchImage;
            PBClose.TabIndex = 5;
            PBClose.TabStop = false;
            // 
            // PicBR
            // 
            PicBR.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PicBR.Image = (Image)resources.GetObject("PicBR.Image");
            PicBR.Location = new Point(2661, 7);
            PicBR.Name = "PicBR";
            PicBR.Size = new Size(27, 27);
            PicBR.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBR.TabIndex = 4;
            PicBR.TabStop = false;
            PicBR.Visible = false;
            // 
            // picBMinimize
            // 
            picBMinimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            picBMinimize.Image = (Image)resources.GetObject("picBMinimize.Image");
            picBMinimize.Location = new Point(2617, 7);
            picBMinimize.Name = "picBMinimize";
            picBMinimize.Size = new Size(27, 27);
            picBMinimize.SizeMode = PictureBoxSizeMode.StretchImage;
            picBMinimize.TabIndex = 3;
            picBMinimize.TabStop = false;
            // 
            // PicBClose
            // 
            PicBClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PicBClose.Image = (Image)resources.GetObject("PicBClose.Image");
            PicBClose.Location = new Point(2705, 7);
            PicBClose.Name = "PicBClose";
            PicBClose.Size = new Size(27, 27);
            PicBClose.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBClose.TabIndex = 2;
            PicBClose.TabStop = false;
            // 
            // PicBMaximize
            // 
            PicBMaximize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PicBMaximize.Image = (Image)resources.GetObject("PicBMaximize.Image");
            PicBMaximize.Location = new Point(2661, 7);
            PicBMaximize.Name = "PicBMaximize";
            PicBMaximize.Size = new Size(27, 27);
            PicBMaximize.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBMaximize.TabIndex = 1;
            PicBMaximize.TabStop = false;
            // 
            // FormAddB
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1115, 640);
            Controls.Add(panelFondo);
            FormBorderStyle = FormBorderStyle.None;
            MinimumSize = new Size(680, 500);
            Name = "FormAddB";
            Text = "FormAddB";
            panelFondo.ResumeLayout(false);
            panelFondo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PBLimpiar).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBAgregar).EndInit();
            PanelTitle.ResumeLayout(false);
            PanelTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBMin).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBRest).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBMax).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBR).EndInit();
            ((System.ComponentModel.ISupportInitialize)picBMinimize).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBMaximize).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelFondo;
        internal Panel PanelTitle;
        internal PictureBox PBMin;
        internal PictureBox PBRest;
        internal PictureBox PBMax;
        internal PictureBox PBClose;
        internal PictureBox PicBR;
        internal PictureBox picBMinimize;
        internal PictureBox PicBClose;
        internal PictureBox PicBMaximize;
        internal TextBox txtBoxDate;
        internal PictureBox PBLimpiar;
        internal PictureBox PBAgregar;
        internal TextBox txtBoxRT;
        internal TextBox txtBoxR5;
        internal TextBox txtBoxR4;
        internal TextBox txtBoxR3;
        internal TextBox txtBoxR2;
        internal TextBox txtBoxR1;
        internal TextBox txtBoxAutor;
        internal TextBox txtBoxReseñas;
        internal TextBox txtBoxRating;
        internal TextBox txtBoxIdioma;
        internal TextBox txtBoxISBN;
        internal TextBox txtBoxEditorial;
        internal TextBox txtBoxAño;
        internal TextBox txtBoxDia;
        internal TextBox txtBoxMes;
        internal TextBox txtBoxPaginas;
        internal TextBox txtBoxTitulo;
        internal Label Label13;
        internal Label Label14;
        internal Label Label15;
        internal Label Label16;
        internal Label Label17;
        internal Label Label18;
        internal Label Label19;
        internal Label Label20;
        internal Label Label21;
        internal Label Label10;
        internal Label Label11;
        internal Label Label6;
        internal Label Label7;
        internal Label Label8;
        internal Label Label9;
        internal Label Label4;
        internal Label Label5;
        internal Label Label3;
        internal Label Label2;
        internal PictureBox pictureBox5;
        internal PictureBox BtnClose;
        internal Label label1;
    }
}