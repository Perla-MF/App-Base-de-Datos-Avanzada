﻿namespace GoodreadsC
{
    partial class FormEditB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEditB));
            panelFondo = new Panel();
            pictureBox1 = new PictureBox();
            Label23 = new Label();
            CBoxAutor = new ComboBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            DataGVBooks = new DataGridView();
            PanelInfo = new Panel();
            picBDelete = new PictureBox();
            Clean = new PictureBox();
            txtID = new TextBox();
            Label22 = new Label();
            txtBoxRT = new TextBox();
            Label14 = new Label();
            Save = new PictureBox();
            Label15 = new Label();
            txtBoxDate = new TextBox();
            txtBoxR5 = new TextBox();
            txtBoxRating = new TextBox();
            txtBoxR4 = new TextBox();
            txtBoxIdioma = new TextBox();
            Label16 = new Label();
            txtBoxR3 = new TextBox();
            txtBoxISBN = new TextBox();
            Label17 = new Label();
            Label18 = new Label();
            Label19 = new Label();
            Label20 = new Label();
            Label12 = new Label();
            txtBoxR2 = new TextBox();
            Label21 = new Label();
            txtBoxEditorial = new TextBox();
            txtBoxR1 = new TextBox();
            txtBoxAño = new TextBox();
            txtBoxDia = new TextBox();
            txtBoxMes = new TextBox();
            txtBoxPaginas = new TextBox();
            txtBoxAutor = new TextBox();
            txtBoxTitulo = new TextBox();
            Label11 = new Label();
            txtBoxReseñas = new TextBox();
            Label6 = new Label();
            Label7 = new Label();
            Label8 = new Label();
            Label9 = new Label();
            Label4 = new Label();
            Label5 = new Label();
            Label3 = new Label();
            Label10 = new Label();
            PanelTitle = new Panel();
            pictureBox5 = new PictureBox();
            PictureBox2 = new PictureBox();
            label1 = new Label();
            BtnMin = new PictureBox();
            BtnRest = new PictureBox();
            BtnMax = new PictureBox();
            BtnClose = new PictureBox();
            PBMin = new PictureBox();
            PBRest = new PictureBox();
            PBMax = new PictureBox();
            PBClose = new PictureBox();
            PicBR = new PictureBox();
            picBMinimize = new PictureBox();
            PicBClose = new PictureBox();
            PicBMaximize = new PictureBox();
            panelFondo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DataGVBooks).BeginInit();
            PanelInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picBDelete).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Clean).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Save).BeginInit();
            PanelTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnMin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnRest).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnMax).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBMin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBRest).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBMax).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBR).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picBMinimize).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBMaximize).BeginInit();
            SuspendLayout();
            // 
            // panelFondo
            // 
            panelFondo.BackColor = Color.Cornsilk;
            panelFondo.Controls.Add(pictureBox1);
            panelFondo.Controls.Add(Label23);
            panelFondo.Controls.Add(CBoxAutor);
            panelFondo.Controls.Add(pictureBox7);
            panelFondo.Controls.Add(pictureBox6);
            panelFondo.Controls.Add(DataGVBooks);
            panelFondo.Controls.Add(PanelInfo);
            panelFondo.Controls.Add(PanelTitle);
            panelFondo.Dock = DockStyle.Fill;
            panelFondo.Location = new Point(0, 0);
            panelFondo.Name = "panelFondo";
            panelFondo.Size = new Size(1153, 794);
            panelFondo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(737, 79);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(40, 38);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 66;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // Label23
            // 
            Label23.AutoSize = true;
            Label23.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label23.Location = new Point(415, 86);
            Label23.Name = "Label23";
            Label23.Size = new Size(62, 24);
            Label23.TabIndex = 65;
            Label23.Text = "Autor";
            // 
            // CBoxAutor
            // 
            CBoxAutor.FormattingEnabled = true;
            CBoxAutor.Location = new Point(492, 84);
            CBoxAutor.Name = "CBoxAutor";
            CBoxAutor.Size = new Size(242, 28);
            CBoxAutor.TabIndex = 64;
            CBoxAutor.SelectedIndexChanged += CBoxAutor_SelectedIndexChanged;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(786, 69);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 53);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 63;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(1077, 69);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 56);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 61;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // DataGVBooks
            // 
            DataGVBooks.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            DataGVBooks.BackgroundColor = Color.Cornsilk;
            DataGVBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGVBooks.Location = new Point(413, 149);
            DataGVBooks.Name = "DataGVBooks";
            DataGVBooks.RowHeadersWidth = 51;
            DataGVBooks.Size = new Size(717, 620);
            DataGVBooks.TabIndex = 58;
            DataGVBooks.CellContentClick += DataGVBooks_CellContentClick;
            // 
            // PanelInfo
            // 
            PanelInfo.BackColor = Color.Tan;
            PanelInfo.Controls.Add(picBDelete);
            PanelInfo.Controls.Add(Clean);
            PanelInfo.Controls.Add(txtID);
            PanelInfo.Controls.Add(Label22);
            PanelInfo.Controls.Add(txtBoxRT);
            PanelInfo.Controls.Add(Label14);
            PanelInfo.Controls.Add(Save);
            PanelInfo.Controls.Add(Label15);
            PanelInfo.Controls.Add(txtBoxDate);
            PanelInfo.Controls.Add(txtBoxR5);
            PanelInfo.Controls.Add(txtBoxRating);
            PanelInfo.Controls.Add(txtBoxR4);
            PanelInfo.Controls.Add(txtBoxIdioma);
            PanelInfo.Controls.Add(Label16);
            PanelInfo.Controls.Add(txtBoxR3);
            PanelInfo.Controls.Add(txtBoxISBN);
            PanelInfo.Controls.Add(Label17);
            PanelInfo.Controls.Add(Label18);
            PanelInfo.Controls.Add(Label19);
            PanelInfo.Controls.Add(Label20);
            PanelInfo.Controls.Add(Label12);
            PanelInfo.Controls.Add(txtBoxR2);
            PanelInfo.Controls.Add(Label21);
            PanelInfo.Controls.Add(txtBoxEditorial);
            PanelInfo.Controls.Add(txtBoxR1);
            PanelInfo.Controls.Add(txtBoxAño);
            PanelInfo.Controls.Add(txtBoxDia);
            PanelInfo.Controls.Add(txtBoxMes);
            PanelInfo.Controls.Add(txtBoxPaginas);
            PanelInfo.Controls.Add(txtBoxAutor);
            PanelInfo.Controls.Add(txtBoxTitulo);
            PanelInfo.Controls.Add(Label11);
            PanelInfo.Controls.Add(txtBoxReseñas);
            PanelInfo.Controls.Add(Label6);
            PanelInfo.Controls.Add(Label7);
            PanelInfo.Controls.Add(Label8);
            PanelInfo.Controls.Add(Label9);
            PanelInfo.Controls.Add(Label4);
            PanelInfo.Controls.Add(Label5);
            PanelInfo.Controls.Add(Label3);
            PanelInfo.Controls.Add(Label10);
            PanelInfo.Dock = DockStyle.Left;
            PanelInfo.Location = new Point(0, 40);
            PanelInfo.Name = "PanelInfo";
            PanelInfo.Size = new Size(398, 754);
            PanelInfo.TabIndex = 33;
            // 
            // picBDelete
            // 
            picBDelete.Image = (Image)resources.GetObject("picBDelete.Image");
            picBDelete.Location = new Point(260, 677);
            picBDelete.Name = "picBDelete";
            picBDelete.Size = new Size(61, 65);
            picBDelete.SizeMode = PictureBoxSizeMode.StretchImage;
            picBDelete.TabIndex = 70;
            picBDelete.TabStop = false;
            picBDelete.Click += picBDelete_Click;
            // 
            // Clean
            // 
            Clean.Image = (Image)resources.GetObject("Clean.Image");
            Clean.Location = new Point(175, 686);
            Clean.Name = "Clean";
            Clean.Size = new Size(53, 56);
            Clean.SizeMode = PictureBoxSizeMode.StretchImage;
            Clean.TabIndex = 68;
            Clean.TabStop = false;
            Clean.Click += Clean_Click;
            // 
            // txtID
            // 
            txtID.Enabled = false;
            txtID.Location = new Point(224, 24);
            txtID.Name = "txtID";
            txtID.ReadOnly = true;
            txtID.Size = new Size(170, 27);
            txtID.TabIndex = 67;
            // 
            // Label22
            // 
            Label22.AutoSize = true;
            Label22.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label22.Location = new Point(11, 27);
            Label22.Name = "Label22";
            Label22.Size = new Size(29, 24);
            Label22.TabIndex = 66;
            Label22.Tag = "";
            Label22.Text = "ID";
            // 
            // txtBoxRT
            // 
            txtBoxRT.Location = new Point(225, 640);
            txtBoxRT.Name = "txtBoxRT";
            txtBoxRT.Size = new Size(170, 27);
            txtBoxRT.TabIndex = 64;
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label14.Location = new Point(12, 643);
            Label14.Name = "Label14";
            Label14.Size = new Size(150, 24);
            Label14.TabIndex = 55;
            Label14.Text = "Rating D. Total";
            // 
            // Save
            // 
            Save.Image = (Image)resources.GetObject("Save.Image");
            Save.Location = new Point(69, 686);
            Save.Name = "Save";
            Save.Size = new Size(53, 56);
            Save.SizeMode = PictureBoxSizeMode.StretchImage;
            Save.TabIndex = 60;
            Save.TabStop = false;
            Save.Click += Save_Click;
            // 
            // Label15
            // 
            Label15.AutoSize = true;
            Label15.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label15.Location = new Point(11, 610);
            Label15.Name = "Label15";
            Label15.Size = new Size(88, 24);
            Label15.TabIndex = 54;
            Label15.Text = "Rating 5";
            // 
            // txtBoxDate
            // 
            txtBoxDate.Location = new Point(225, 442);
            txtBoxDate.Name = "txtBoxDate";
            txtBoxDate.Size = new Size(170, 27);
            txtBoxDate.TabIndex = 65;
            // 
            // txtBoxR5
            // 
            txtBoxR5.Location = new Point(225, 607);
            txtBoxR5.Name = "txtBoxR5";
            txtBoxR5.Size = new Size(170, 27);
            txtBoxR5.TabIndex = 63;
            // 
            // txtBoxRating
            // 
            txtBoxRating.Location = new Point(225, 343);
            txtBoxRating.Name = "txtBoxRating";
            txtBoxRating.Size = new Size(170, 27);
            txtBoxRating.TabIndex = 46;
            // 
            // txtBoxR4
            // 
            txtBoxR4.Location = new Point(225, 574);
            txtBoxR4.Name = "txtBoxR4";
            txtBoxR4.Size = new Size(170, 27);
            txtBoxR4.TabIndex = 62;
            // 
            // txtBoxIdioma
            // 
            txtBoxIdioma.Location = new Point(225, 310);
            txtBoxIdioma.Name = "txtBoxIdioma";
            txtBoxIdioma.Size = new Size(170, 27);
            txtBoxIdioma.TabIndex = 45;
            // 
            // Label16
            // 
            Label16.AutoSize = true;
            Label16.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label16.Location = new Point(12, 577);
            Label16.Name = "Label16";
            Label16.Size = new Size(88, 24);
            Label16.TabIndex = 53;
            Label16.Text = "Rating 4";
            // 
            // txtBoxR3
            // 
            txtBoxR3.Location = new Point(225, 541);
            txtBoxR3.Name = "txtBoxR3";
            txtBoxR3.Size = new Size(170, 27);
            txtBoxR3.TabIndex = 61;
            // 
            // txtBoxISBN
            // 
            txtBoxISBN.Location = new Point(225, 277);
            txtBoxISBN.Name = "txtBoxISBN";
            txtBoxISBN.Size = new Size(170, 27);
            txtBoxISBN.TabIndex = 44;
            // 
            // Label17
            // 
            Label17.AutoSize = true;
            Label17.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label17.Location = new Point(11, 544);
            Label17.Name = "Label17";
            Label17.Size = new Size(88, 24);
            Label17.TabIndex = 52;
            Label17.Text = "Rating 3";
            // 
            // Label18
            // 
            Label18.AutoSize = true;
            Label18.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label18.Location = new Point(11, 511);
            Label18.Name = "Label18";
            Label18.Size = new Size(88, 24);
            Label18.TabIndex = 51;
            Label18.Text = "Rating 2";
            // 
            // Label19
            // 
            Label19.AutoSize = true;
            Label19.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label19.Location = new Point(11, 478);
            Label19.Name = "Label19";
            Label19.Size = new Size(88, 24);
            Label19.TabIndex = 50;
            Label19.Text = "Rating 1";
            // 
            // Label20
            // 
            Label20.AutoSize = true;
            Label20.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label20.Location = new Point(11, 445);
            Label20.Name = "Label20";
            Label20.Size = new Size(67, 24);
            Label20.TabIndex = 49;
            Label20.Text = "Fecha";
            // 
            // Label12
            // 
            Label12.AutoSize = true;
            Label12.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label12.Location = new Point(12, 379);
            Label12.Name = "Label12";
            Label12.Size = new Size(205, 24);
            Label12.TabIndex = 47;
            Label12.Text = "No. Total de reseñas";
            // 
            // txtBoxR2
            // 
            txtBoxR2.Location = new Point(225, 508);
            txtBoxR2.Name = "txtBoxR2";
            txtBoxR2.Size = new Size(170, 27);
            txtBoxR2.TabIndex = 60;
            // 
            // Label21
            // 
            Label21.AutoSize = true;
            Label21.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label21.Location = new Point(12, 412);
            Label21.Name = "Label21";
            Label21.Size = new Size(62, 24);
            Label21.TabIndex = 48;
            Label21.Text = "Autor";
            // 
            // txtBoxEditorial
            // 
            txtBoxEditorial.Location = new Point(225, 244);
            txtBoxEditorial.Name = "txtBoxEditorial";
            txtBoxEditorial.Size = new Size(170, 27);
            txtBoxEditorial.TabIndex = 43;
            // 
            // txtBoxR1
            // 
            txtBoxR1.Location = new Point(225, 475);
            txtBoxR1.Name = "txtBoxR1";
            txtBoxR1.Size = new Size(170, 27);
            txtBoxR1.TabIndex = 59;
            // 
            // txtBoxAño
            // 
            txtBoxAño.Location = new Point(225, 211);
            txtBoxAño.Name = "txtBoxAño";
            txtBoxAño.Size = new Size(170, 27);
            txtBoxAño.TabIndex = 42;
            // 
            // txtBoxDia
            // 
            txtBoxDia.Location = new Point(225, 178);
            txtBoxDia.Name = "txtBoxDia";
            txtBoxDia.Size = new Size(170, 27);
            txtBoxDia.TabIndex = 41;
            // 
            // txtBoxMes
            // 
            txtBoxMes.Location = new Point(225, 143);
            txtBoxMes.Name = "txtBoxMes";
            txtBoxMes.Size = new Size(170, 27);
            txtBoxMes.TabIndex = 40;
            // 
            // txtBoxPaginas
            // 
            txtBoxPaginas.Location = new Point(225, 109);
            txtBoxPaginas.Name = "txtBoxPaginas";
            txtBoxPaginas.Size = new Size(170, 27);
            txtBoxPaginas.TabIndex = 39;
            // 
            // txtBoxAutor
            // 
            txtBoxAutor.Location = new Point(225, 409);
            txtBoxAutor.Name = "txtBoxAutor";
            txtBoxAutor.Size = new Size(170, 27);
            txtBoxAutor.TabIndex = 58;
            // 
            // txtBoxTitulo
            // 
            txtBoxTitulo.Location = new Point(225, 76);
            txtBoxTitulo.Name = "txtBoxTitulo";
            txtBoxTitulo.Size = new Size(170, 27);
            txtBoxTitulo.TabIndex = 38;
            txtBoxTitulo.TextChanged += txtBoxTitulo_TextChanged;
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label11.Location = new Point(11, 346);
            Label11.Name = "Label11";
            Label11.Size = new Size(71, 24);
            Label11.TabIndex = 37;
            Label11.Text = "Rating";
            // 
            // txtBoxReseñas
            // 
            txtBoxReseñas.Location = new Point(225, 376);
            txtBoxReseñas.Name = "txtBoxReseñas";
            txtBoxReseñas.Size = new Size(170, 27);
            txtBoxReseñas.TabIndex = 57;
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label6.Location = new Point(11, 313);
            Label6.Name = "Label6";
            Label6.Size = new Size(72, 24);
            Label6.TabIndex = 36;
            Label6.Text = "Idioma";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label7.Location = new Point(12, 280);
            Label7.Name = "Label7";
            Label7.Size = new Size(56, 24);
            Label7.TabIndex = 35;
            Label7.Text = "ISBN";
            // 
            // Label8
            // 
            Label8.AutoSize = true;
            Label8.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label8.Location = new Point(12, 247);
            Label8.Name = "Label8";
            Label8.Size = new Size(88, 24);
            Label8.TabIndex = 34;
            Label8.Text = "Editorial";
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label9.Location = new Point(12, 214);
            Label9.Name = "Label9";
            Label9.Size = new Size(190, 24);
            Label9.TabIndex = 33;
            Label9.Text = "Año de publicación";
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label4.Location = new Point(11, 181);
            Label4.Name = "Label4";
            Label4.Size = new Size(184, 24);
            Label4.TabIndex = 32;
            Label4.Text = "Día de publicación";
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label5.Location = new Point(11, 146);
            Label5.Name = "Label5";
            Label5.Size = new Size(192, 24);
            Label5.TabIndex = 31;
            Label5.Text = "Mes de publicación";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label3.Location = new Point(12, 112);
            Label3.Name = "Label3";
            Label3.Size = new Size(123, 24);
            Label3.TabIndex = 30;
            Label3.Text = "No. Páginas";
            // 
            // Label10
            // 
            Label10.AutoSize = true;
            Label10.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label10.Location = new Point(12, 79);
            Label10.Name = "Label10";
            Label10.Size = new Size(65, 24);
            Label10.TabIndex = 29;
            Label10.Text = "Título";
            // 
            // PanelTitle
            // 
            PanelTitle.BackColor = Color.FromArgb(108, 59, 42);
            PanelTitle.Controls.Add(pictureBox5);
            PanelTitle.Controls.Add(PictureBox2);
            PanelTitle.Controls.Add(label1);
            PanelTitle.Controls.Add(BtnMin);
            PanelTitle.Controls.Add(BtnRest);
            PanelTitle.Controls.Add(BtnMax);
            PanelTitle.Controls.Add(BtnClose);
            PanelTitle.Controls.Add(PBMin);
            PanelTitle.Controls.Add(PBRest);
            PanelTitle.Controls.Add(PBMax);
            PanelTitle.Controls.Add(PBClose);
            PanelTitle.Controls.Add(PicBR);
            PanelTitle.Controls.Add(picBMinimize);
            PanelTitle.Controls.Add(PicBClose);
            PanelTitle.Controls.Add(PicBMaximize);
            PanelTitle.Dock = DockStyle.Top;
            PanelTitle.Location = new Point(0, 0);
            PanelTitle.Name = "PanelTitle";
            PanelTitle.Size = new Size(1153, 40);
            PanelTitle.TabIndex = 3;
            PanelTitle.MouseMove += PanelTitle_MouseMove;
            // 
            // pictureBox5
            // 
            pictureBox5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(1103, 6);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(27, 27);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 44;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // PictureBox2
            // 
            PictureBox2.Image = (Image)resources.GetObject("PictureBox2.Image");
            PictureBox2.Location = new Point(12, 3);
            PictureBox2.Name = "PictureBox2";
            PictureBox2.Size = new Size(35, 34);
            PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox2.TabIndex = 9;
            PictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(45, 3);
            label1.Name = "label1";
            label1.Size = new Size(172, 32);
            label1.TabIndex = 43;
            label1.Text = "Editar Libro";
            // 
            // BtnMin
            // 
            BtnMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnMin.Image = (Image)resources.GetObject("BtnMin.Image");
            BtnMin.Location = new Point(1927, 6);
            BtnMin.Name = "BtnMin";
            BtnMin.Size = new Size(27, 27);
            BtnMin.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnMin.TabIndex = 12;
            BtnMin.TabStop = false;
            // 
            // BtnRest
            // 
            BtnRest.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnRest.Image = (Image)resources.GetObject("BtnRest.Image");
            BtnRest.Location = new Point(1974, 6);
            BtnRest.Name = "BtnRest";
            BtnRest.Size = new Size(27, 27);
            BtnRest.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnRest.TabIndex = 11;
            BtnRest.TabStop = false;
            BtnRest.Visible = false;
            // 
            // BtnMax
            // 
            BtnMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnMax.Image = (Image)resources.GetObject("BtnMax.Image");
            BtnMax.Location = new Point(1974, 6);
            BtnMax.Name = "BtnMax";
            BtnMax.Size = new Size(27, 27);
            BtnMax.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnMax.TabIndex = 10;
            BtnMax.TabStop = false;
            // 
            // BtnClose
            // 
            BtnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnClose.Image = (Image)resources.GetObject("BtnClose.Image");
            BtnClose.Location = new Point(2020, 6);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(27, 27);
            BtnClose.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnClose.TabIndex = 9;
            BtnClose.TabStop = false;
            // 
            // PBMin
            // 
            PBMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBMin.Image = (Image)resources.GetObject("PBMin.Image");
            PBMin.Location = new Point(2706, 3);
            PBMin.Name = "PBMin";
            PBMin.Size = new Size(27, 27);
            PBMin.SizeMode = PictureBoxSizeMode.StretchImage;
            PBMin.TabIndex = 8;
            PBMin.TabStop = false;
            // 
            // PBRest
            // 
            PBRest.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBRest.Image = (Image)resources.GetObject("PBRest.Image");
            PBRest.Location = new Point(2748, 3);
            PBRest.Name = "PBRest";
            PBRest.Size = new Size(27, 27);
            PBRest.SizeMode = PictureBoxSizeMode.StretchImage;
            PBRest.TabIndex = 7;
            PBRest.TabStop = false;
            PBRest.Visible = false;
            // 
            // PBMax
            // 
            PBMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBMax.Image = (Image)resources.GetObject("PBMax.Image");
            PBMax.Location = new Point(2792, 3);
            PBMax.Name = "PBMax";
            PBMax.Size = new Size(27, 27);
            PBMax.SizeMode = PictureBoxSizeMode.StretchImage;
            PBMax.TabIndex = 6;
            PBMax.TabStop = false;
            // 
            // PBClose
            // 
            PBClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PBClose.Image = (Image)resources.GetObject("PBClose.Image");
            PBClose.Location = new Point(2838, 3);
            PBClose.Name = "PBClose";
            PBClose.Size = new Size(27, 27);
            PBClose.SizeMode = PictureBoxSizeMode.StretchImage;
            PBClose.TabIndex = 5;
            PBClose.TabStop = false;
            // 
            // PicBR
            // 
            PicBR.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PicBR.Image = (Image)resources.GetObject("PicBR.Image");
            PicBR.Location = new Point(3614, 7);
            PicBR.Name = "PicBR";
            PicBR.Size = new Size(27, 27);
            PicBR.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBR.TabIndex = 4;
            PicBR.TabStop = false;
            PicBR.Visible = false;
            // 
            // picBMinimize
            // 
            picBMinimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            picBMinimize.Image = (Image)resources.GetObject("picBMinimize.Image");
            picBMinimize.Location = new Point(3570, 7);
            picBMinimize.Name = "picBMinimize";
            picBMinimize.Size = new Size(27, 27);
            picBMinimize.SizeMode = PictureBoxSizeMode.StretchImage;
            picBMinimize.TabIndex = 3;
            picBMinimize.TabStop = false;
            // 
            // PicBClose
            // 
            PicBClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PicBClose.Image = (Image)resources.GetObject("PicBClose.Image");
            PicBClose.Location = new Point(3658, 7);
            PicBClose.Name = "PicBClose";
            PicBClose.Size = new Size(27, 27);
            PicBClose.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBClose.TabIndex = 2;
            PicBClose.TabStop = false;
            // 
            // PicBMaximize
            // 
            PicBMaximize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            PicBMaximize.Image = (Image)resources.GetObject("PicBMaximize.Image");
            PicBMaximize.Location = new Point(3614, 7);
            PicBMaximize.Name = "PicBMaximize";
            PicBMaximize.Size = new Size(27, 27);
            PicBMaximize.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBMaximize.TabIndex = 1;
            PicBMaximize.TabStop = false;
            // 
            // FormEditB
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1153, 794);
            Controls.Add(panelFondo);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormEditB";
            Text = "FormEditB";
            Load += FormEditB_Load;
            panelFondo.ResumeLayout(false);
            panelFondo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)DataGVBooks).EndInit();
            PanelInfo.ResumeLayout(false);
            PanelInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picBDelete).EndInit();
            ((System.ComponentModel.ISupportInitialize)Clean).EndInit();
            ((System.ComponentModel.ISupportInitialize)Save).EndInit();
            PanelTitle.ResumeLayout(false);
            PanelTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnMin).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnRest).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnMax).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBMin).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBRest).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBMax).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBR).EndInit();
            ((System.ComponentModel.ISupportInitialize)picBMinimize).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBMaximize).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelFondo;
        internal Panel PanelTitle;
        internal PictureBox PictureBox2;
        internal Label label1;
        internal PictureBox BtnMin;
        internal PictureBox BtnRest;
        internal PictureBox BtnMax;
        internal PictureBox BtnClose;
        internal PictureBox PBMin;
        internal PictureBox PBRest;
        internal PictureBox PBMax;
        internal PictureBox PBClose;
        internal PictureBox PicBR;
        internal PictureBox picBMinimize;
        internal PictureBox PicBClose;
        internal PictureBox PicBMaximize;
        internal PictureBox pictureBox5;
        internal Label Label23;
        internal ComboBox CBoxAutor;
        internal PictureBox pictureBox7;
        internal PictureBox pictureBox6;
        internal PictureBox Save;
        internal DataGridView DataGVBooks;
        internal Panel PanelInfo;
        internal TextBox txtID;
        internal Label Label22;
        internal TextBox txtBoxRT;
        internal Label Label14;
        internal Label Label15;
        internal TextBox txtBoxDate;
        internal TextBox txtBoxR5;
        internal TextBox txtBoxRating;
        internal TextBox txtBoxR4;
        internal TextBox txtBoxIdioma;
        internal Label Label16;
        internal TextBox txtBoxR3;
        internal TextBox txtBoxISBN;
        internal Label Label17;
        internal Label Label18;
        internal Label Label19;
        internal Label Label20;
        internal Label Label12;
        internal TextBox txtBoxR2;
        internal Label Label21;
        internal TextBox txtBoxEditorial;
        internal TextBox txtBoxR1;
        internal TextBox txtBoxAño;
        internal TextBox txtBoxDia;
        internal TextBox txtBoxMes;
        internal TextBox txtBoxPaginas;
        internal TextBox txtBoxAutor;
        internal TextBox txtBoxTitulo;
        internal Label Label11;
        internal TextBox txtBoxReseñas;
        internal Label Label6;
        internal Label Label7;
        internal Label Label8;
        internal Label Label9;
        internal Label Label4;
        internal Label Label5;
        internal Label Label3;
        internal Label Label10;
        internal PictureBox Clean;
        internal PictureBox pictureBox1;
        internal PictureBox picBDelete;
    }
}